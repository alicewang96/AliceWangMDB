//
//  CollectionViewCell.swift
//  Memeify
//
//  Created by Alice Wang on 2/20/16.
//  Copyright © 2016 MOBILEDEVSBERKELEY. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var joke: UITextView!
    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var white: UILabel!
}
