//
//  MemePictureViewController.swift
//  Memeify
//
//  Created by SAMEER SURESH on 2/19/16.
//  Copyright © 2016 MOBILEDEVSBERKELEY. All rights reserved.
//

import UIKit

class MemePictureViewController: UIViewController {
    //THESE VARIABLES SHOULD BE MODIFIED FROM YOUR COLLECTION VIEW CONTROLLER
    var imageName = ""
    @IBOutlet weak var memePic: UIImageView!
    
    
    //LEAVE THESE VARIABLES ALONE
    var timer = NSTimer()
    var times = 0
    var colors = [UIColor.redColor(), UIColor.greenColor(), UIColor.purpleColor(), UIColor.blueColor(), UIColor.blackColor(), UIColor.brownColor(), UIColor.magentaColor(), UIColor.yellowColor(), UIColor.orangeColor(), UIColor.cyanColor()]
    @IBOutlet weak var overlay: UIImageView!
    
    //LEAVE THIS FUNCTION ALONE
    override func viewDidLoad() {
        super.viewDidLoad()
        /*SET MEMEPIC TO WHATEVER PICTURE WAS PASSED IN FROM THE COLLECTION VIEW*/
        /*
            YOUR CODE HERE
        */
        memePic.image = UIImage(named:imageName)
        
        //LEAVE THIS STUFF ALONE
        overlay.image = overlay.image!.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate)
        overlay.tintColor = UIColor.redColor()
        timer = NSTimer.scheduledTimerWithTimeInterval(0.6, target: self, selector: "changeColor", userInfo: nil, repeats: true)
    }
    
    //LEAVE THIS FUNCTION ALONE
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //LEAVE THIS FUNCTION ALONE
    func changeColor(){
        if times < 30{
            overlay.image = overlay.image!.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate)
            overlay.tintColor = colors[times%colors.count]
            times = times + 1
        }
        else{
            timer.invalidate()
        }
    }

}
