//
//  ImageViewController.swift
//  Memeify
//
//  Created by Alice Wang on 2/24/16.
//  Copyright © 2016 MOBILEDEVSBERKELEY. All rights reserved.
//

import UIKit

class ImageViewController: UIImageViewController {

}
