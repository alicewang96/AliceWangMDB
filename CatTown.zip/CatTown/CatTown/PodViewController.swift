//
//  PodViewController.swift
//  CatTown
//
//  Created by Alice Wang on 3/1/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit
import HoneycombView

class PodViewController: UIViewController {

    var images = [UIImage]()
    var images2 = ["british", "persian", "bengel", "shorthair", "toyfer"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for i in 0..<5{
            images.append(UIImage(named: images2[i])!)
        }
        
        
        let honeycombView = HoneycombView(frame: CGRectMake(0, 0, view.frame.width, view.frame.height/1.5))
        honeycombView.center = CGPointMake(view.frame.width/2, view.frame.height/2)
        honeycombView.diameter = 100.0
        honeycombView.margin = 1.0
        honeycombView.configrationForHoneycombViewWithImages(images)
        view.addSubview(honeycombView)
        
        honeycombView.animate(2.0)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

