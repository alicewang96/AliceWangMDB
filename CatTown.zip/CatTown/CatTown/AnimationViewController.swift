//
//  AnimationViewController.swift
//  CatTown
//
//  Created by Alice Wang on 3/1/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit

class AnimationViewController: UIViewController {

    @IBOutlet weak var chase: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        chase.center.x  -= view.bounds.width
        
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        UIView.animateWithDuration(1.0, delay: 0.4, options: .Repeat, animations: {
            self.chase.center.x += (self.view.bounds.width)/2;
            self.chase.center.y += (self.view.bounds.height)/2
            }, completion: nil)
//        usleep(10000)
//        UIView.animateWithDuration(1.0, delay: 0.4, options: [], animations: {
//            self.chase.center.y += (self.view.bounds.height)/2
//            }, completion: nil)
//        usleep(10000)
//        UIView.animateWithDuration(1.0, delay: 0.4, options: [], animations: {
//            self.chase.center.x -= (self.view.bounds.height)/2
//            }, completion: nil)
        
//        UIView.animateWithDuration(0.5, delay: 0.6,
//            options: .Repeat, animations: {
//                self.chase.center.x += self.view.bounds.width
//            }, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
