//
//  ViewController.swift
//  CatTown
//
//  Created by Alice Wang on 3/1/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var cat: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        cat.center.x  -= view.bounds.width
        
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)

        UIView.animateWithDuration(0.5, delay: 0.9,
            options: .Repeat, animations: {
                self.cat.alpha = 0.5
            }, completion: nil)
    }

}

