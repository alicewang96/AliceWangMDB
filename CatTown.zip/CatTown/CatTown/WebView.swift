//
//  WebView.swift
//  CatTown
//
//  Created by Alice Wang on 3/1/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit

class WebView: UIWebView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
