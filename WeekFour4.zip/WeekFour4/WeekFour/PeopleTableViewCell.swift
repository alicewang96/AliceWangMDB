//
//  PeopleTableViewCell.swift
//  WeekFour
//
//  Created by Alice Wang on 3/9/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

class PeopleTableViewCell: UITableViewCell {

    @IBOutlet weak var personusername: UILabel!
}
