//
//  SignupViewController.swift
//  WeekFour
//
//  Created by Alice Wang on 3/8/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {

    @IBOutlet weak var first: UITextField!
    @IBOutlet weak var last: UITextField!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var confirm: UITextField!
    @IBOutlet weak var email: UITextField!
    
    func displayAlert(titel: String, displayError: String) {
        let alert = UIAlertController(title: title, message: displayError, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title:"OK", style: UIAlertActionStyle.Default, handler: { action in
            self.dismissViewControllerAnimated(true, completion: nil)}))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func signup(sender: AnyObject) {
//        var displayError = ""
//        if username.text == "" {
//            displayError = "Please enter a username."
//        } else if password.text == "" {
//            displayError = "Please enter a password."
//        } else if first.text == "" {
//            displayError = "Please enter a first name."
//        } else if last.text == "" {
//            displayError = "Please enter a last name."
//        } else if confirm.text == "" {
//            displayError = "Please confirm password."
//        } else if email.text == "" {
//            displayError = "Please enter an email."
//        } else if password.text != confirm.text {
//            displayError = "Passwords do not match."
//        }
//        if displayError != "" {
//            displayAlert("Incomplete Form.", displayError: displayError)
//        } else {
            let user = PFUser()
//        user["username"] = username.text
            user.username = username.text
            user.password = password.text
            user.email = email.text
            user.signUpInBackground()
        self.performSegueWithIdentifier("signFeed", sender: self)
            
//            user.signUpInBackgroundWithBlock{ (succeeded, signupError) -> Void in
//                if signupError == nil {self.performSegueWithIdentifier("signFeed", sender: self)
//                    
//                } else {
//                    if let error = signupError!.userInfo["error"] as? NSString{
//                        displayError = error as String
//                    } else {
//                        displayError = "Please try again later"
//                    }
//                }
//            }
            
//        }
    }

//override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//    if segue.identifier == "signFeed" {
//        let Info = segue.destinationViewController as! NewSocialViewController
//        Info.username = username.text!
//        Info.firstname = password.text!
//        Info.lastname = password.text!
//        
//    }
//}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
