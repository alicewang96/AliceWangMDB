//
//  EventCollectionViewCell.swift
//  WeekFour
//
//  Created by Alice Wang on 3/8/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit

class EventCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var eventname: UIButton!
}
