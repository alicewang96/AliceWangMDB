//
//  SocialDetailViewController.swift
//  WeekFour
//
//  Created by Alice Wang on 3/8/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit

class SocialDetailViewController: UIViewController,UITableViewDelegate, UITableViewDataSource  {

    
    @IBOutlet weak var eventImage: UIImageView!
    @IBOutlet weak var peopleTableView: UITableView!
    @IBOutlet weak var eventName: UILabel!
    var people = Array<String>()
    var notpeople = NSMutableArray()
    var names = Array<String>()
    var username = ""
    var user = PFUser.currentUser()
    var event = ""
    var socialId = "";
    var locationstring = ""
    var timestring = ""
    var detailstring = ""
    var imagefiles = NSData()
    @IBOutlet weak var details: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var location: UILabel!
    
    @IBAction func rsvp(sender: AnyObject) {
//        var query = PFQuery(className:"Socials")
//        query.getObjectInBackgroundWithId("xWMyZEGZ") {
//            (gameScore: PFObject?, error: NSError?) -> Void in
//            if error != nil {
//                print(error)
//            } else if let gameScore = gameScore {
//                gameScore["cheatMode"] = true
//                gameScore["score"] = 1338
//                gameScore.saveInBackground()
//            }
//        }
        let query = PFQuery(className:"Socials")
        
        query.getObjectInBackgroundWithId(socialId) {
            (social: PFObject?, error: NSError?) -> Void in
            if error == nil && social != nil {
                social!.addUniqueObject((self.user?.objectId)!, forKey:"goingUserObjectIds")
                social!.saveInBackground()
                social!.removeObject((self.user?.objectId)!, forKey:"notGoingUserObjectIds")
                social!.saveInBackground()
                print((self.user?.objectId)!)
                let query = PFQuery(className:"_User")
                query.whereKey("objectId", equalTo: (self.user?.objectId)!)
                query.findObjectsInBackgroundWithBlock {
                    (objects: [PFObject]?, error: NSError?) -> Void in
                    if error == nil {
                        // The find succeeded.
                        print("Successfully retrieved \(objects!.count) scores.")
                        // Do something with the found objects
                        if let objects = objects {
                            for object in objects {
                                if !self.names.contains(object["username"] as! String) {
                                    self.names.append(object["username"] as! String)
                                }
                            }
                            self.peopleTableView.reloadData()
                        }
                    } else {
                        print("Error")
                    }
                }
                self.peopleTableView.reloadData()
            } else {
                print(error)
            }
        }
    }
    func update() {
        let query = PFQuery(className:"User")
        query.whereKey("objectId", containedIn: people as [AnyObject])
        query.findObjectsInBackgroundWithBlock {
            (objects: [PFObject]?, error: NSError?) -> Void in
            if error == nil {
                if let objects = objects {
                    for object in objects {
                        self.names.append(object["username"] as! String)
                    }
                    self.peopleTableView.reloadData()
                } else {
                    print("error")
                }
            }
        }
    }
    func getObjectId() {
        let query = PFQuery(className: "Socials")
        do {
            let objects = try query.findObjects()
            for object in objects {
                if object["socialTitle"]as!String == event {
                    socialId = object.objectId!
                }
            }
        } catch {
            print("Error")
        }
    }
    @IBAction func notgoing(sender: AnyObject) {
        let query = PFQuery(className:"Socials")
        
        query.getObjectInBackgroundWithId(socialId) {
            (social: PFObject?, error: NSError?) -> Void in
            if error == nil && social != nil{
                social!.addUniqueObject((self.user?.objectId)!, forKey:"notGoingUserObjectIds")
                social!.saveInBackground()
                social!.removeObject((self.user?.objectId)!, forKey:"goingUserObjectIds")
                social!.saveInBackground()
                print((self.user?.objectId)!)
                let query = PFQuery(className:"_User")
                query.whereKey("objectId", equalTo: (self.user?.objectId)!)
                query.findObjectsInBackgroundWithBlock {
                    (objects: [PFObject]?, error: NSError?) -> Void in
                    if error == nil {
                        // The find succeeded.
                        print("Successfully retrieved \(objects!.count) scores.")
                        // Do something with the found objects
                        if let objects = objects {
                            for object in objects {
                                if self.names.contains(object["username"] as! String) {
                                    self.names.removeAtIndex(self.names.indexOf(object["username"] as! String)!)
                                }
                            }
                            self.peopleTableView.reloadData()
                        }
                    } else {
                        print("Error")
                    }
                }
                self.peopleTableView.reloadData()
            } else {
                print(error)
            }
        }
        
    }
        //get user info
        //add user to array for this event
        //--need to parse to get the array of people
        //--append user to the array
        //--put the array back into the parse row for the event
     

    override func viewDidLoad() {
        super.viewDidLoad()
        peopleTableView.delegate = self
        peopleTableView.dataSource = self

//        peopleTableView.registerClass(UITableViewCell.self, forHeaderFooterViewReuseIdentifier: "person")
        // Do any additional setup after loading the view.
//        getUsers()
        eventName.text = event
        details.text = detailstring
        location.text = locationstring
        time.text = timestring
//        }
        getObjectId()
        update()
        eventImage.image = UIImage(data: imagefiles)
        self.peopleTableView.reloadData()
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = peopleTableView.dequeueReusableCellWithIdentifier("person", forIndexPath: indexPath) as! PeopleTableViewCell
        cell.personusername.text = names[indexPath.row] as! String
        return cell
    }
//    func getUsers() {
        // Get the list of all the members' names and add them to the memberNames array. Then reload the tableview.
//        let query = PFQuery(className:"Socials")
//        query.whereKey("socialTitle", equalTo: event)
//        query.findObjectsInBackgroundWithBlock {
//            (objects: [PFObject]?, error: NSError?) -> Void in
//            
//            if error == nil {
//                // Do something with the found objects
//                if let objects = objects! as? [PFObject] {
//                    self.people = objects["goingUserObjectIds"] as! Array<String>
//                }
//            }
//            self.peopleTableView.reloadData()
//        }
        
//    }
//    func getUsers() {
//            let query = PFQuery(className:"Socials")
//            do {
//                try self.people = query.findObjects()[
//            } catch {
//                print("Error")
//            }
//            peopleTableView.reloadData()
//        }
//
//    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
