//
//  NavigationFeedNavigationController.swift
//  WeekFour
//
//  Created by Alice Wang on 3/12/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//


class NavigationFeedNavigationController: UINavigationController {

}
