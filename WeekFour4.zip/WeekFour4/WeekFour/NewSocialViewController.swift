//
//  NewSocialViewController.swift
//  WeekFour
//
//  Created by Alice Wang on 3/8/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit

class NewSocialViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    var username = ""
    var firstname = ""
    var lastname = ""
    
    @IBOutlet weak var tempImage: UIImageView!
    @IBOutlet weak var event: UITextField!
    @IBOutlet weak var date: UITextField!
    @IBOutlet weak var location: UITextField!
    @IBOutlet weak var details: UITextField!
    
    @IBAction func choosePicture(sender: AnyObject) {
        let image = UIImagePickerController()
        image.delegate = self
        image.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        image.allowsEditing = false
    self.presentViewController(image, animated: true, completion: nil)
        
    }
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
        self.dismissViewControllerAnimated(true, completion: nil)
        tempImage.image = image
        
        
    }
    
    func displayAlert(titel: String, displayError: String) {
        let alert = UIAlertController(title: title, message: displayError, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title:"OK", style: UIAlertActionStyle.Default, handler: { action in
            self.dismissViewControllerAnimated(true, completion: nil)}))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func createEvent(sender: AnyObject) {
        var displayError = ""
        if event.text == "" {
            displayError = "Please enter an event name."
        } else if date.text == "" {
            displayError = "Please enter a date."
        } else if location.text == "" {
            displayError = "Please enter a location."
        } else if details.text == ""{
            displayError = "Please enter a brief description."
        }
//        else if date.text.format != "dd/M/yyyy, H:mm" {
//            displayError = "Please formate date as dd/M/yyyy, H:mm"
//        }
        if displayError != "" {
            displayAlert("Error in Form", displayError: displayError)
        } else {
            let social = PFObject(className: "Socials")
            social["socialTitle"] = event.text
            social["socialInformation"] = details.text
            social["socialLocation"] = location.text
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd hh:mm"
            let dateFormat = dateFormatter.dateFromString(date.text!)
            social["socialTime"] = dateFormat
            let eventPic = PFFile(name: "eventPic.png", data: UIImageJPEGRepresentation(tempImage.image!, 0.5)!)
            social["socialPicture"] = eventPic
            
            social.saveInBackground()
//            social.saveInBackgroundWithBlock {
//                    (success: Bool, error: NSError?) -> Void in
//                    if (success) {
//                        self.performSegueWithIdentifier("createdEvent", sender: self)
//                    } else {
//                        self.displayAlert("Fill form correctly", displayError: displayError)
//                }
//                }
//            self.displayAlert("Fill form correctly", displayError: displayError)
//            
            self.performSegueWithIdentifier("createdEvent", sender: self)
            
            
            
            //            let user = PFUser()
            //            user.username = username.text
            //            user.password = password.text
//            let social = PFSocials
//            

//            
            
 //WHAT IS THE CREATE EVENT EQUIVALENT TO LOGIN/SIGNUP
//            PFUser.logInWithUsernameInBackground(username.text!, password: password.text!) {
//                (success, loginError) in
//                if loginError == nil {
//                } else {
//                    if let errorString = loginError!.userInfo["error"] as? NSString {
//                        displayError = errorString as String
//                    } else {
//                        displayError = "Please try again later"
//                    }
//                    self.displayAlert("Could Not Create Event", displayError: displayError)
//                }
//            }
            
            
            
        }

    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
