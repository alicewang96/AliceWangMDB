//
//  SecondViewController.swift
//  TipCalculator
//
//  Created by Alice Wang on 2/16/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var amountTextField: UITextField!
    @IBOutlet weak var tenPercentLabel: UILabel!
    @IBOutlet weak var fifteenPercentLabel: UILabel!

    @IBOutlet weak var twentyPercentLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.amountTextField.delegate = self;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func calculate(sender: UIButton) {
        //if someone put an alphabet, what happens
        if (amountTextField.text == "") {
            return
        } else {
            let amount:Double = Double(amountTextField.text!)!
            let ten:Double = amount * 0.1
            let fift:Double = amount * 0.15
            let twen:Double = amount * 0.2
            tenPercentLabel.text = String(ten)
            fifteenPercentLabel.text = String(fift)
            twentyPercentLabel.text = String(twen)
        }
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
