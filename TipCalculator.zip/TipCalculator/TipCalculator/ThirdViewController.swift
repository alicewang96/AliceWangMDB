//
//  ThirdViewController.swift
//  TipCalculator
//
//  Created by Alice Wang on 2/16/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet var foodText: UITextField!

    @IBOutlet weak var factText: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.foodText.delegate = self;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func generateFoodFact(sender: UIButton) {
        if (foodText.text == "peanuts") || (foodText.text == "peanut") || (foodText.text == "Peanut"){
            factText.text = "Peanuts are one of the ingredients of dynamite."
        } else if (foodText.text == "almonds") || (foodText.text == "almond")||(foodText.text == "Almond") {
            factText.text = "Almonds are a member of the peach family."
        } else if (foodText.text == "cashews") || (foodText.text == "cashew") || (foodText.text == "Cashew"){
            factText.text = "Cashews are a natural antidepressant."
        } else if (foodText.text == "apples") || (foodText.text == "apple") || (foodText.text == "Apple"){
            factText.text = "25% of an apple's volume is made up of air."
        }
        else {
            factText.text = "Sorry, please enter peanut, apple, almond or cashew.. Will be updated soon?"
        }
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
