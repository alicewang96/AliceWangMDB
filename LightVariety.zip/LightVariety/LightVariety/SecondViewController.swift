//
//  SecondViewController.swift
//  LightVariety
//
//  Created by Alice Wang on 2/16/16.
//  Copyright © 2016 Alice Wang. All rights reserved.
//

import UIKit
import AVFoundation

class SecondViewController: UIViewController {
    var stop = 0;
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func toggleFlash() {
        let device = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
        if (device.hasTorch) {
            do {
                try device.lockForConfiguration()
                if (device.torchMode == AVCaptureTorchMode.On) {
                    device.torchMode = AVCaptureTorchMode.Off
                } else {
                    do {
                        try device.setTorchModeOnWithLevel(1.0)
                    } catch {
                        print(error)
                    }
                }
                device.unlockForConfiguration()
            } catch {
                print(error)
            }
        }
    }
    @IBAction func singleButton(sender: UIButton) {
        if stop == 1 { stop = 0
            toggleFlash()
        }
        toggleFlash()
        sleep(1)
        toggleFlash()
    }
    @IBAction func secondButton(sender: UIButton) {
        if stop == 1 { stop = 0
            toggleFlash()
        }
        toggleFlash()
        usleep(90000)
        toggleFlash()
        usleep(90000)
        toggleFlash()
        usleep(90000)
        toggleFlash()
    }
    @IBAction func infButton(sender: AnyObject) {
        if stop == 1 { stop = 0
            toggleFlash()
        }
        stop = 1;
        toggleFlash()
    }
    @IBAction func raveButton(sender: AnyObject) {
        if stop == 1 { stop = 0
            toggleFlash()
        }
        var seizure:Int = 51
        while(seizure > 0) {
            seizure--;
        toggleFlash()
            usleep(80000)
        }
        toggleFlash()
    }
    @IBAction func sosButton(sender: UIButton) {
        if stop == 1 { stop = 0
            toggleFlash()
        }
        for var i = 0; i < 3; i++ {
            
            toggleFlash()
            usleep(100000)
            toggleFlash()
            usleep(100000)
        }
        for var i = 0; i < 3; i++ {
            toggleFlash()
            usleep(230000)
            toggleFlash()
            usleep(230000)
        }
        for var i = 0; i < 3; i++ {
            
            toggleFlash()
            usleep(100000)
            toggleFlash()
            usleep(100000)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
